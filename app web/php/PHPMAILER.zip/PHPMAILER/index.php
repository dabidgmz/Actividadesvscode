<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'david.gmzherrera28@gmail.com';
    $mail->Password   = 'xlnshlmmmphviuuh';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port       = 465;

    // Destinatarios
    $mail->setFrom('fdavid.gmzherrera28@gmail.com', 'David');
    $mail->addAddress('fgolmos10@gmail.com', 'Joe User');

    // Contenido del correo electrónico
    $mail->isHTML(true);
    $mail->Subject = 'Detalles de la compra';

    // Aquí debes obtener la información relevante de la compra y asignarla a variables
    $cliente = 'David Gomez Herrera';
    $imagenProducto = 'descarga.jpeg';
    $caracteristicas = 'Producto: Kipling 4065
    Nombre: Kipling 4065
    Marca: Chaviza
    Tipo de lente: Monofocales
    Precio: $1955.99
    Categoría: Adultos';

    // Construir el cuerpo del correo con los detalles de la compra
    $body = '<h2>Detalles de la compra</h2>';
    $body .= '<p>Cliente: ' . $cliente . '</p>';
    $body .= '<p>Imagen del producto:<br><img src="cid:imagen_producto" alt="Imagen del producto"></p>';
    $body .= '<p>Características del producto:<br>' . nl2br($caracteristicas) . '</p>';

    $mail->Body = $body;
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    // Adjuntar la imagen del producto
    $mail->addEmbeddedImage($imagenProducto, 'imagen_producto');

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>
